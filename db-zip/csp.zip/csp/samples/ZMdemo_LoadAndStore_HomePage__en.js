﻿
/* Localization in en for ZMdemo.LoadAndStore.HomePage */

if (!window._zenTEXT) { window._zenTEXT = {}; }

window._zenTEXT['Zen Mojo Demo\/Name:']='Name:';
window._zenTEXT['Zen Mojo Demo\/SSN:']='SSN:';
window._zenTEXT['Zen Mojo Demo\/Home City:']='Home City:';
window._zenTEXT['Zen Mojo Demo\/Home City']='Home City';
window._zenTEXT['Zen Mojo Demo\/SSN']='SSN';
window._zenTEXT['Zen Mojo Demo\/Name']='Name';
